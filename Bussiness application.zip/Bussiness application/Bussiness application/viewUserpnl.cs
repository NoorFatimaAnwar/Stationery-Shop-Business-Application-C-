﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class viewUserpnl : UserControl
    {
        public viewUserpnl()
        {
            InitializeComponent();
        }

        private void viewUserpnl_Load(object sender, EventArgs e)
        {
          
                List<MUser> loadUserList = MUserDL.returnUserList();
                if (loadUserList.Count > 0)
                {
                    /*dataGridView1.DataSource = null;*/
                    dataGridView1.DataSource = loadUserList;
                    dataGridView1.Refresh();

                }
                else
                {
                    dataGridView1.Hide();
                }
            
        }
    }
}
