﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_application.BL;
using Bussiness_application.DL;

namespace Bussiness_application
{
    public partial class SignUpForm : Form
    {
        public SignUpForm() 
        {
            InitializeComponent();
        }

       

        private void button2_Click(object sender, EventArgs e) // signIn code
        {
            string username = txtname.Text;
            bool check = MUserDL.isValid(username);
            if (check)
            {
                MUser user = new MUser(txtname.Text, txtpass.Text, comboBox1.Text);
                MUserDL.addUser(user);
                MUserDL.storeUser(user, "user.txt");
                if (user != null)
                {
                    MessageBox.Show("added successfully");
                }
            }
            else
            {
                MessageBox.Show("Inavlid userName");
            }
            txtname.Text = string.Empty;
            txtpass.Text = string.Empty;
            comboBox1.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form moreForm = new SignInForm();
            moreForm.Show();
        }

        private void SignUpForm_Load(object sender, EventArgs e)
        {

        }
    }
}
