﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class placeOrderpnl : UserControl
    {
        public placeOrderpnl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oderName = textBox1.Text;
            int verifing = orderDL.isValidPro(oderName);
            if (verifing != -1)
            {
                List<item> list = productDL.getProductList();
                order orderPro = new order(textBox1.Text, int.Parse(textBox2.Text));
                if (orderPro != null)
                {
                    orderDL.addOrderInList(orderPro);
                    
                    list[verifing].setItemNumber(int.Parse(textBox2.Text));
                    productDL.UpdateIteminFile("items.txt");
                    string buyerName = SignInForm.getCustomerName();
                    int totalBill = billDL.calaculateBill();
                    bill customerBill = new bill(buyerName, totalBill);
                    billDL.addInBillList(customerBill);
                    MessageBox.Show("added successfully");

                }
                else
                {
                    MessageBox.Show("Invalid input");
                }
            }
            else
            {
                MessageBox.Show("Product does not exit");
            }

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
        }

        private void placeOrderpnl_Load(object sender, EventArgs e)
        {

        }
    }
}
