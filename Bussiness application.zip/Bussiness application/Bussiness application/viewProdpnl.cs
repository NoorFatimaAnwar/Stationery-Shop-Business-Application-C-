﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class viewProdpnl : UserControl
    {
        public viewProdpnl()
        {
            InitializeComponent();
        }

        private void viewProdpnl_Load(object sender, EventArgs e)
        {
               //List<MUser> loadUserList = MUserDL.returnUserList();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = productDL.getProductList();
                dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
