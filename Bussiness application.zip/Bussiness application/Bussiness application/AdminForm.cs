﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class AdminForm : Form
    {

        public AdminForm()
        {
            InitializeComponent();
           
          


        }

      
        private void addPanel(UserControl panel) // main panel
        {
            panel.Dock = DockStyle.Fill;
            mainpnl.Controls.Clear();
            mainpnl.Controls.Add(panel);
            panel.BringToFront();
        }
        private void button1_Click(object sender, EventArgs e) // add view product panel
        {
            viewProdpnl viewProdpnl = new viewProdpnl();
            addPanel(viewProdpnl);
        }
        private void button2_Click(object sender, EventArgs e) // add enter panel
        {
            EnterDatapnl enterDatapnl = new EnterDatapnl();
            addPanel(enterDatapnl);


        }
        private void button3_Click(object sender, EventArgs e) // add edit panel
        {
            updatePnl open = new updatePnl();
            addPanel(open);
        }
        private void button4_Click(object sender, EventArgs e) //add view user panel
        {

            ViewUserspnl userPanel = new ViewUserspnl();
            addPanel(userPanel);


        }
        private void button5_Click_1(object sender, EventArgs e) // add feedback panel
        {
            feedbackPanel showFeedback = new feedbackPanel();
            addPanel(showFeedback);
        }

        private void button6_Click_1(object sender, EventArgs e) // add worker panel
        {
            WorkerPnl showworker = new WorkerPnl();
            addPanel(showworker);
        }

        private void button7_Click_1(object sender, EventArgs e) // exit
        {
            this.Hide();
            Form moreForm = new SignInForm();
            moreForm.Show();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }

       

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
     

        private void button5_Click(object sender, EventArgs e)
        {
                     

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
           /* string deletePro = textBox4.Text;
            bool check = productDL.DeleteItem("item.txt",deletePro);
            if(check == true)
            {
                MessageBox.Show("Product deleted sucessfully");
            }
            else
            {
                MessageBox.Show("Invalid input");
            }
            textBox4.Text = string.Empty;*/
        }
      


        private void button7_Click(object sender, EventArgs e)
        {
           
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint_1(object sender, PaintEventArgs e)
        {
           
        
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void viewUserpnl1_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void number_Click(object sender, EventArgs e)
        {

        }


    }
}
