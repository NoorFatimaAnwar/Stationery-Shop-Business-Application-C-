﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class WorkerPnl : UserControl
    {
        static int index;
        static int selectedRow;
        public WorkerPnl()
        {
            InitializeComponent();
        }

        private void updateOkbtn_Click(object sender, EventArgs e)
        {
            index = dataGridView1.CurrentCell.RowIndex;
            if (index >= 0 && index < dataGridView1.Rows.Count)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                Workers worker = new Workers(textBox6.Text, textBox7.Text, int.Parse(textBox8.Text));
                selectedRow.Cells[0].Value = textBox6.Text;
                selectedRow.Cells[1].Value = (textBox7.Text);
                selectedRow.Cells[2].Value = int.Parse(textBox8.Text);
                dataGridView1.Refresh();
                bool istrue = WorkerDL.UpdateWorkerinFile("worker.txt");
                if (istrue)
                {
                    MessageBox.Show("worker Updated");
                }
                else
                {
                    MessageBox.Show("worker cannot updated");
                }
            }


            textBox6.Text = string.Empty;
            textBox7.Text = string.Empty;
            textBox8.Text = string.Empty;
        }

        private void WorkerPnl_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = WorkerDL.getWorkerList();
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            selectedRow = dataGridView1.CurrentCell.RowIndex;
            List<Workers> workerList = WorkerDL.getWorkerList();
            workerList.RemoveAt(selectedRow);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = workerList;
            dataGridView1.Refresh();
            bool istrue = WorkerDL.UpdateWorkerinFile("worker.txt");
            if (istrue)
            {
                MessageBox.Show("Worker Deleted");
            }
            else
            {
                MessageBox.Show("Worker cannot deleted");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Workers worker = new Workers(textBox6.Text, textBox7.Text, int.Parse(textBox8.Text));
            if(worker != null)
            {
                List<Workers> workerList = WorkerDL.getWorkerList();
                WorkerDL.addWorkerInList(worker);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = workerList;
                dataGridView1.Refresh();
                bool istrue = WorkerDL.storeWorkerInFile(worker ,"worker.txt");
                
                if (istrue)
                {
                    MessageBox.Show("worker added");
                }
                else
                {
                    MessageBox.Show("worker cannot added");
                }
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
         
        }
    }
}
