﻿
namespace Bussiness_application
{
    partial class EnterDatapnl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterOkbtn = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.number = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // enterOkbtn
            // 
            this.enterOkbtn.BackColor = System.Drawing.Color.Teal;
            this.enterOkbtn.Location = new System.Drawing.Point(351, 262);
            this.enterOkbtn.Name = "enterOkbtn";
            this.enterOkbtn.Size = new System.Drawing.Size(75, 30);
            this.enterOkbtn.TabIndex = 13;
            this.enterOkbtn.Text = "OK";
            this.enterOkbtn.UseVisualStyleBackColor = false;
            this.enterOkbtn.Click += new System.EventHandler(this.enterOkbtn_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(229, 182);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(196, 20);
            this.textBox3.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(229, 130);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(196, 20);
            this.textBox2.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(229, 77);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(197, 20);
            this.textBox1.TabIndex = 10;
            // 
            // number
            // 
            this.number.AutoSize = true;
            this.number.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number.Location = new System.Drawing.Point(101, 180);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(122, 20);
            this.number.TabIndex = 9;
            this.number.Text = "Product Numbers:";
            // 
            // price
            // 
            this.price.AutoSize = true;
            this.price.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price.Location = new System.Drawing.Point(122, 130);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(98, 20);
            this.price.TabIndex = 8;
            this.price.Text = "Product Price:";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(122, 75);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(101, 20);
            this.name.TabIndex = 7;
            this.name.Text = "Product Name:";
            // 
            // EnterDatapnl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Controls.Add(this.enterOkbtn);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.number);
            this.Controls.Add(this.price);
            this.Controls.Add(this.name);
            this.Name = "EnterDatapnl";
            this.Size = new System.Drawing.Size(552, 422);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button enterOkbtn;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label number;
        private System.Windows.Forms.Label price;
        private System.Windows.Forms.Label name;
    }
}
