﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class bill
    {
        string customerName;
        int Bill;

        public string CustomerName { get => customerName; set => customerName = value; }
        public int totalBill { get => Bill; set => Bill = value; }

        public bill(string customerName , int Bill)
        {
            this.customerName = customerName;
            this.Bill = Bill;
        }
        public string getCustomerName()
        {
            return this.customerName;
        }
        public int getBill()
        {
            return this.Bill;
        }
    }
}
