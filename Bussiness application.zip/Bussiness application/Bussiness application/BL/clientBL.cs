﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class clientBL : MUser
    {
        public clientBL(string name, string password) : base(name, password)
        {

        }
     
    }
}
