﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class item
    {
         
        private string itemName;
        private int itemPrice;
        private int numOfItem;

        public string ItemName { get => itemName; set => itemName = value; }
        public int ItemPrice { get => itemPrice; set => itemPrice = value; }
        public int NumOfItem { get => numOfItem; set => numOfItem = value; }

        public item()
        {

        }
        public item(string itemName, int itemPrice, int numOfItem)
        {
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.numOfItem = numOfItem;
        }
       
        public void setItemName(string name)
        {

            this.itemName = name;

        }
        public string getItemName()
        {

            return this.itemName;

        }

        public void setItemPrice(int price)
        {
            if (price > 0)
            {
                this.itemPrice = price;
            }
        }
        public int getItemPrice()
        {

            return this.itemPrice;

        }
        public void setItemNumber(int num)
        {
            if (num > 0)
            {
                this.numOfItem = this.numOfItem - num;
            }
        }
        public int getItemNumber()
        {

            return this.numOfItem;

        }
        public bool decreaseItemNumber(int des)
        {
            if (des > 0 && this.numOfItem > 0)
            {
                this.numOfItem = this.numOfItem - des;
                return true;
            }
            else
                return false;
        }
    }
}
