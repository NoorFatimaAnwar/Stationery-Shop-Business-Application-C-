﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class MUser
    {
        private string userNames;
        private string userpasswords;
        private string roles;

        public string UserNames { get => userNames; set => userNames = value; }
        public string Userpasswords { get => userpasswords; set => userpasswords = value; }
        public string Roles { get => roles; set => roles = value; }

        public MUser(string userNames, string userpasswords)
        {
            this.userNames = userNames;
            this.userpasswords = userpasswords;
        }

        public MUser(string userNames, string userpasswords, string roles)
        {
            this.userNames = userNames;
            this.userpasswords = userpasswords;
            this.roles = roles;
        }
        public bool isAdmin()
        {
            if (roles == "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string getUserName()
        {
            return this.userNames;
        }
        public string getUserPassword()
        {
            return this.userpasswords;
        }
        public string getUserRole()
        {
            return this.roles;
        }
    }
}

