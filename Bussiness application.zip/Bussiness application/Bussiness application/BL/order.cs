﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class order
    {
      private string orderName;
        private int orderNum;
        
        public order(string orderName , int orderNum)
        {
            this.orderName = orderName;
            this.orderNum = orderNum;
        }

        public string OrderName { get => orderName; set => orderName = value; }
        public int OrderNum { get => orderNum; set => orderNum = value; }

        public string getProName()
        {
            return this.orderName;
        }
        public int getProNum()
        {
            return this.orderNum;
        }
    }
}
