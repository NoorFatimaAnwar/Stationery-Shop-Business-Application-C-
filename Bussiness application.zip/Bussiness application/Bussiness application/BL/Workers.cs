﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class Workers
    {
        private string workerName;
        private string workerRole;
        private float workerSalary;

        public string WorkerName { get => workerName; set => workerName = value; }
        public string WorkerRole { get => workerRole; set => workerRole = value; }
        public float WorkerSalary { get => workerSalary; set => workerSalary = value; }

        public Workers()
        {

        }
        public Workers(string workerName, string workerRole, float workerSalary)
        {
            this.workerName = workerName;
            this.workerRole = workerRole;
            this.workerSalary = workerSalary;
        }

        public void setWorkerName(string workerName)
        {

            this.workerName = workerName;

        }
        public string getWorkerName()
        {

            return this.workerName;

        }

        public void setWorkerRole(string workerRole)
        {


            this.workerRole = workerRole;

        }
        public string getWorkerRole()
        {

            return this.workerRole;

        }
        public void setWorkerSalary(float salary)
        {
            if (salary > 0)
            {
                this.workerSalary = salary;
            }
        }
        public float getWorkerSalary()
        {

            return this.workerSalary;

        }
    }
}
