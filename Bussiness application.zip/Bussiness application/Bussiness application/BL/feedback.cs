﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.BL
{
    class feedback
    {
        private string name;
        private string FeedBack;

        public feedback(string name , string FeedBack)
        {
            this.name = name;
            this.FeedBack = FeedBack;
        }

        public string getName()
         {
            return this.name;
        }
        public string getFeedback()
        {
            return this.FeedBack;
        }
        public string Name { get => name; set => name = value; }
        public string FeedBack1 { get => FeedBack; set => FeedBack = value; }
    }
}
