﻿using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class OpenUpdatepnl : UserControl
    {
        public OpenUpdatepnl()
        {
            InitializeComponent();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
             bool checkValid = productDL.ISValid(textBox1.Text);
            if (checkValid == true)
            {

               
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
            textBox1.Text = string.Empty;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
