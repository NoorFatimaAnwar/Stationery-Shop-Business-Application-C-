﻿using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application.BL
{
    public partial class displayBill : UserControl
    {
        public displayBill()
        {
            InitializeComponent();
        }

        private void displayBill_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = billDL.getBillsList();
            dataGridView1.Refresh();
        }
    }
}
