﻿using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            string path = "user.txt";
            string proPath = "items.txt";
            string feebackPath = "Feedback.txt";
            string workerPath = "worker.txt";
            // load data from files
            if (MUserDL.loadData(path) && productDL.loadItemFromFile(proPath)
               && feedbackDL.loadFeedbackFromFile(feebackPath) && WorkerDL.loadWorkerFromFile(workerPath))
            {
                MessageBox.Show("Data loaded from file");
            }
            else
            {
                MessageBox.Show("Data not loaded from file");
            }

        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                Form moreForm = new SignInForm();
                moreForm.Show();
                radioButton1.Checked = false;
            }
            if (radioButton2.Checked)
            {
                Form moreForm = new SignUpForm();
                moreForm.Show();
                radioButton2.Checked = false;
            }
            if (radioButton4.Checked)
            {
                this.Close();
            }
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
