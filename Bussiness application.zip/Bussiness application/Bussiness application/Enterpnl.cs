﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class EnterDatapnl : UserControl
    {
        public EnterDatapnl()
        {
            InitializeComponent();
        }

        private void enterOkbtn_Click(object sender, EventArgs e)
        {

            item pro = new item(textBox1.Text, int.Parse(textBox2.Text), int.Parse(textBox3.Text));
            if (pro != null)
            {
                productDL.addItem(pro);
                productDL.storeItemInFile(pro, "items.txt");

                MessageBox.Show("added successfully");

            }
            else
            {
                MessageBox.Show("Invalid input");
            }

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
        }
    }
}
