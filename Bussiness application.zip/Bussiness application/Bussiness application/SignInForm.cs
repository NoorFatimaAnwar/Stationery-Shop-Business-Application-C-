﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class SignInForm : Form
    {
       static string customerNames;
        public SignInForm()
        {
            InitializeComponent();
            orderDL.clearOrderList();
            billDL.clearBillList();
        }
        private void ClearDataFromForm()
        {
            textBox1.Text = "";
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            customerNames = textBox1.Text;
            MUser user = new MUser(username, password);
            string validUser = MUserDL.signIn(user); // check user valid 
            if(validUser != null)
            {

                if (validUser == "Admin")
                {
                    this.Hide();
                    Form moreForm = new AdminForm();// open admin form
                    moreForm.Show();
                }
                else
                {
                    this.Hide();
                    Form moreForm = new ClientForm(); // open client form
                    moreForm.Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
            textBox1.Text= string.Empty;
            textBox2.Text = string.Empty;
        }
        public static string getCustomerName()
        {
            return customerNames;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form moreForm = new SignUpForm();
            moreForm.Show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SignInForm_Load(object sender, EventArgs e)
        {

        }

       
    }
}
