﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class deleteOrder : UserControl
    {
        public deleteOrder()
        {
            InitializeComponent();
        }

        private void deleteOrder_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = orderDL.getOrderedList();
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int selectedRow = -1;
            selectedRow = dataGridView1.CurrentCell.RowIndex;
            
            if (selectedRow != -1)
            {
                List<order> odrList = orderDL.getOrderedList();
                odrList.RemoveAt(selectedRow);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = odrList;
                dataGridView1.Refresh();
                string buyerName = SignInForm.getCustomerName();
                int totalBill = billDL.calaculateBill();
                bill customerBill = new bill(buyerName, totalBill);
                billDL.addInBillList(customerBill);
                MessageBox.Show("Order product is deleted");
            }
            else
            {
                MessageBox.Show("invalid input");
            }
        }
    }
}
