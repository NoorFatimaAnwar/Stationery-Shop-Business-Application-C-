﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application.DL
{
    public partial class enterOrder : UserControl
    {
        public enterOrder()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oderName = textBox1.Text;
           // bool verifing = orderDL.isValidPro(oderName);
            order orderPro = new order(textBox1.Text, int.Parse(textBox2.Text));
            if (orderPro != null)
            {
                orderDL.addOrderInList(orderPro);
                

                MessageBox.Show("added successfully");

            }
            else
            {
                MessageBox.Show("Invalid input");
            }

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
           
        }
    }
}
