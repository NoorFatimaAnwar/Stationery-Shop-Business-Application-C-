﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_application.BL;

namespace Bussiness_application
{
    public partial class updatePnl : UserControl
    {
        static int index;
        static int selectedRow;
        public updatePnl()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            index = dataGridView1.CurrentCell.RowIndex;
            if(index >= 0 && index < dataGridView1.Rows.Count)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                item product = new item(textBox6.Text, int.Parse(textBox7.Text), int.Parse(textBox8.Text));
                selectedRow.Cells[0].Value = textBox6.Text;
                selectedRow.Cells[1].Value = int.Parse(textBox7.Text);
                selectedRow.Cells[2].Value = int.Parse(textBox8.Text);
                dataGridView1.Refresh();
                bool istrue = productDL.UpdateIteminFile("items.txt");
                if (istrue)
                {
                    MessageBox.Show("Product Updated");
                }
                else
                {
                    MessageBox.Show("Product cannot updated");
                }
            }
                              
                  
            textBox6.Text = string.Empty;
            textBox7.Text = string.Empty;
            textBox8.Text = string.Empty;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void updatePnl_Load(object sender, EventArgs e)
        {
            //List<MUser> loadUserList = MUserDL.returnUserList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productDL.getProductList();
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            selectedRow = dataGridView1.CurrentCell.RowIndex;
            List<item> itemList = productDL.getProductList();
            itemList.RemoveAt(selectedRow);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = itemList;
            dataGridView1.Refresh();
            bool istrue= productDL.deleteItemFromFile("items.txt");
            if (istrue)
            {
                MessageBox.Show("Product Deleted");
            }
            else
            {
                MessageBox.Show("Product cannot deleted");
            }

            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
