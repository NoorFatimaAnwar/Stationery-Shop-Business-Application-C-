﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class ClientForm : Form
    {
        public ClientForm()
        {
            InitializeComponent();
        }
        private void addClientPanel(UserControl panel) // add client panel to main panel
        {
            panel.Dock = DockStyle.Fill;
            clientMain.Controls.Clear();
            clientMain.Controls.Add(panel);
            panel.BringToFront();
        }
        private void button1_Click(object sender, EventArgs e)// add view panel
        {
            viewProdpnl viewProdpnl = new viewProdpnl();
            addClientPanel(viewProdpnl);
        }

        private void button2_Click(object sender, EventArgs e)// add place order panel
        {
            placeOrderpnl order = new placeOrderpnl();
            addClientPanel(order);
        }

      

        private void button3_Click_1(object sender, EventArgs e) // add view order panel
        {
            viewOrder vieworder = new viewOrder();
            addClientPanel(vieworder);
        }

      

        private void button4_Click_1(object sender, EventArgs e) // add delete order panel
        {
            deleteOrder deleteorder = new deleteOrder();
            addClientPanel(deleteorder);
        }

        private void button5_Click(object sender, EventArgs e)// add display bill panel
        {
            
            displayBill display = new displayBill();
            addClientPanel(display);
        }

        private void button6_Click(object sender, EventArgs e) // add give feedback panel
        {
            giveFeedback feedbacks = new giveFeedback();
            addClientPanel(feedbacks);
        }

        private void button7_Click(object sender, EventArgs e)// exit
        {
            this.Hide();
            Form moreForm = new SignInForm();
            moreForm.Show();
        }
        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
