﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class orderDL
    {
        private static List<order> orderList = new List<order>();

        public static List<order> getOrderedList()
        {
            return orderList;
        }

        public static void addOrderInList(order odr)
        {
            orderList.Add(odr);
        }

        public static int isValidPro(string check)
        {
            int idx = -1;
            List<item> proList = productDL.getProductList();
            for (int i = 0; i < proList.Count; i++)
            {
                if (proList[i].getItemName() == check)
                {
                    idx = i;
                    return idx;
                }
            }
            return idx;
        }

        public static void clearOrderList()
        {
            orderList.Clear();
        }

    }
}
