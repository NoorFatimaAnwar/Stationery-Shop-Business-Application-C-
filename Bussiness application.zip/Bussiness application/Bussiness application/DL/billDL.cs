﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class billDL
    {
        private static List<bill> billList = new List<bill>();
        public static List<bill> getBillsList()
        {
          return  billList;
        }
        public static void addInBillList(bill inp)
        {
            if(billList.Count > 0)
            {
                billList.RemoveAt(0);
                billList.Insert(0, inp);
            }
           else
                billList.Insert(0, inp);
        }

        public static void clearBillList() 
        {
            billList.Clear();
        }
         public static int calaculateBill()
        {
            int sum = 0;
            int total=0;
            int price=0;
            string cusProNames;
            List<order> cusOrder = orderDL.getOrderedList();
            List<item> Product = productDL.getProductList();
            for (int i = 0; i < cusOrder.Count; i++)
            {
                cusProNames = cusOrder[i].getProName();
                for(int j =0; j < Product.Count; j++)
                {
                    if(Product[i].getItemName() == cusProNames)
                    {
                        price = Product[i].getItemPrice();
                    }
                }
                sum = price * cusOrder[i].getProNum();
                total = total + sum;



            }
            return total;
           
        }


    }
}
