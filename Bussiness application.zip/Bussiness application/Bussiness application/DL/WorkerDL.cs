﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class WorkerDL
    {
        private static List<Workers> workerList = new List<Workers>();
        public static List<Workers> getWorkerList()
        {
            return workerList;
        }
        public static void addWorkerInList(Workers w)
        {
            workerList.Add(w);
        }

  

        public static bool checker(string workerNames)
        {

            foreach (Workers work in workerList)
            {
                if (work.getWorkerName() == workerNames)
                {
                    return false;
                }
            }
            return true;
        }

        public static bool storeWorkerInFile(Workers inputs, string Path)
        {

            StreamWriter file1 = new StreamWriter(Path, true);
            if (File.Exists(Path))
            {


                file1.WriteLine(inputs.getWorkerName() + ',' + inputs.getWorkerRole() + ',' + inputs.getWorkerSalary());

                file1.Flush();
                file1.Close();
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool loadWorkerFromFile(string path)
        {


            StreamReader file2 = new StreamReader(path);
            string record;

            if (File.Exists(path))
            {
                while ((record = file2.ReadLine()) != null)
                {

                    string[] splittedData = record.Split(',');
                    string workerName = splittedData[0];
                    string workerRole = (splittedData[1]);
                    float salary = float.Parse(splittedData[2]);
                    Workers w2 = new Workers(workerName, workerRole, salary);
                    workerList.Add(w2);


                }

                file2.Close();
                return true;
            }
            else
            {
                return false;
            }

        }
        public static bool verifingWorker(string Name)
        {
            bool check = false;
            for (int i = 0; i < workerList.Count; i++)
            {
                if (workerList[i].getWorkerName() == Name)
                {

                    check = true;

                }
            }
            return check;
        }
    
        public static bool UpdateWorkerinFile(string path)
        {
            if (File.Exists(path))
            {
                StreamWriter file4 = new StreamWriter(path);


                for (int i = 0; i < workerList.Count; i++)
                {
                    file4.WriteLine(workerList[i].getWorkerName() + ',' + workerList[i].getWorkerRole() + ',' + workerList[i].getWorkerSalary());
                }
                file4.Flush();
                file4.Close();
                return true;
            }
            else
                return false;
        }
    }
}
