﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class MUserDL
    {
        private static List<MUser> userArray = new List<MUser>();
        
        public static void addUser(MUser input)
        {
            userArray.Add(input);
        }
        public static List<MUser> returnUserList()
        {
           return userArray;
        }

        public static string signIn(MUser User) // signIn
        {


            foreach (MUser storedUser in userArray)
            {
                if (User.getUserName() == storedUser.getUserName() && User.getUserPassword() == storedUser.getUserPassword())
                {
                    return storedUser.getUserRole(); 
                }
            }

            return null;
        }
        public static bool isValid(string name)
        {


            for (int i = 0; i < userArray.Count; i++)
            {
                if (userArray[i].getUserName() == name)
                {
                    return false;
                }

            }
            return true;
        }
        public static void storeUser(MUser input, string Path)
        {
            if (File.Exists(Path))
            {
                StreamWriter file = new StreamWriter(Path, true);

                file.WriteLine(input.getUserName() + ',' + input.getUserPassword()+ ',' + input.getUserRole());

                file.Flush();
                file.Close();
            }
        }
        public static bool loadData(string Path)
        {


            StreamReader file = new StreamReader(Path);
            string record;

            if (File.Exists(Path))
            {
                while ((record = file.ReadLine()) != null)
                {

                    string userNames = parseData(record, 1);
                    string userpasswords = parseData(record, 2);
                    string roles = parseData(record, 3);
                    MUser u1 = new MUser(userNames, userpasswords, roles);
                    userArray.Add(u1);


                }

                file.Close();
                return true;
            }
            else
            {
                return false;
            }


        }

        public static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
    }
}
