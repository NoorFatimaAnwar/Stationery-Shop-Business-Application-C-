﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class feedbackDL
    {
        private static List<feedback> FeedBack = new List<feedback>();

        public static List<feedback> getFeedbackList()
        {
            return FeedBack;
        }

        public static void addFeedbackInList(feedback inp)
        {
            FeedBack.Add(inp);
        }
        public static void storeFeedbackFromFile(feedback response,  string Path1)
        {


            StreamWriter file2 = new StreamWriter(Path1);
            

            if (File.Exists(Path1))
            {             

                 file2.WriteLine(response.getName() + ',' + response.getFeedback() );
                                                 

                file2.Close();
                
            }
          

        }
        public static bool loadFeedbackFromFile(string Path1)
        {


            StreamReader file2 = new StreamReader(Path1);
            string record;

            if (File.Exists(Path1))
            {
                while ((record = file2.ReadLine()) != null)
                {

                    
                    string[] splittedData = record.Split(',');
                    string Name = splittedData[0];
                    string feedBack = splittedData[1];
                    feedback fb = new feedback(Name,feedBack);
                    FeedBack.Add(fb);

                }

                file2.Close();
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
