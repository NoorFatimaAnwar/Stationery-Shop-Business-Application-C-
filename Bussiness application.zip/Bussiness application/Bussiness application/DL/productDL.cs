﻿using Bussiness_application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_application.DL
{
    class productDL
    {
        static int n;
        private static List<item> productList = new List<item>();
        public static List<item> getProductList()
        {
            return productList;
        }
        public static void addItem(item i)
        {
            productList.Add(i);
        }

        public static bool ISValid(string check)
        {
            for (int i = 0; i < productList.Count; i++)
            {
                if (productList[i].getItemName() == check)
                {
                    n = i;
                    return true;
                }
            }
            return false;
        }


        public static void storeItemInFile(item input, string Path)
        {

            StreamWriter file1 = new StreamWriter(Path, true);
            if (File.Exists(Path))
            {


                file1.WriteLine(input.getItemName() + ',' + input.getItemPrice() + ',' + input.getItemNumber());

                file1.Flush();
                file1.Close();
            }

        }
        public static bool loadItemFromFile(string path)
        {


            StreamReader file2 = new StreamReader(path);
            string record;

            if (File.Exists(path))
            {
                while ((record = file2.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(record))
                        continue;
                    string[] splittedData = record.Split(',');
                    string itemName = splittedData[0];
                    int itemPrice = int.Parse(splittedData[1]);
                    int numOfItem = int.Parse(splittedData[2]);
                    item i2 = new item(itemName, itemPrice, numOfItem);
                    productList.Add(i2);


                }

                file2.Close();
                return true;
            }
            else
            {
                return false;
            }

        }
      

        public static bool deleteItemFromFile(string Path)
        {

            if (File.Exists(Path))
            {
                StreamWriter file3 = new StreamWriter(Path);


                for (int i = 0; i < productList.Count; i++)
                {
                    file3.WriteLine(productList[i].getItemName() + ',' + productList[i].getItemPrice() + ',' + productList[i].getItemNumber());

                }
                file3.Flush();
                file3.Close();
                return true;
            }
            else
                return false;

        }


   
        public static bool UpdateIteminFile(string path)
        {
            if (File.Exists(path))
            {
                StreamWriter file4 = new StreamWriter(path);


                for (int i = 0; i < productList.Count; i++)
                {
                    file4.WriteLine(productList[i].getItemName() + ',' + productList[i].getItemPrice() + ',' + productList[i].getItemNumber());
                }
                file4.Flush();
                file4.Close();
                return true;
            }
            else
            return false;
        }

        public static string returnMostPriced(int idx)
        {
            return productList[idx].getItemName();

        }
    }
}
