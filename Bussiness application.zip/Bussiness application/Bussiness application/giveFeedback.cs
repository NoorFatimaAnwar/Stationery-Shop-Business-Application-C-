﻿using Bussiness_application.BL;
using Bussiness_application.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bussiness_application
{
    public partial class giveFeedback : UserControl
    {
        public giveFeedback()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            feedback response = new feedback(textBox1.Text, richTextBox1.Text);
            if (textBox1.Text != null && richTextBox1.Text != null)
            {
                feedbackDL.addFeedbackInList(response);
                feedbackDL.storeFeedbackFromFile(response, "Feedback.txt");
                MessageBox.Show("Feedback sent sucessfully");
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }

            textBox1.Text = string.Empty;
            richTextBox1.Text = string.Empty;
        }
    }
}
